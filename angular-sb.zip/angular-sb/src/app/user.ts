export class User {
        userId:string;
        email:string;
        password:string;
        firstName:string;
        lastName:string;
        numberPosts:number;
        isAdmin:boolean;
        birthDate:string;
    }
    

