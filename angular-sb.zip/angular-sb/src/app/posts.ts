export class Posts {

    postId:number;
    userId:number;
    countLikes:number;
    postText:string;
    postDate:string;
    postMediaUrl:string;

}
