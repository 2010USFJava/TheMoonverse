import { Posts } from './posts';

describe('Posts', () => {
  it('should create an instance', () => {
    expect(new Posts()).toBeTruthy();
  });
});
