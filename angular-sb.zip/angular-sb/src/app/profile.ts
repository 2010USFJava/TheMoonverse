export class Profile {

    profileId:number;
    aboutMe:string;
    age:number;
    city:string;
    profession:string;
    favoritePlanet:string;
    profilePicture:string;

}
