export class Profile {

    
    aboutMe:string;
    age:number;
    city:string;
    profession:string;
    favoritePlanet:string;
    profilePicture:string;
    countLikes: number;
    userId: number;

}
